#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>


SEXP R_do_rec_apply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env);
SEXP R_do_tree_delete_node();


static R_CallMethodDef CallEntries[] = {
    {"R_do_rec_apply", (DL_FUNC) &R_do_rec_apply, 6},
    {"R_do_tree_delete_node", (DL_FUNC)&R_do_tree_delete_node, 0},
    {NULL, NULL, 0}
};

          
void
R_init_treeApply(DllInfo *info)
{
  /* Register routines, allocate resources. */
  R_registerRoutines(info, NULL /* Centries*/, CallEntries /*CallEntries*/,
		       NULL /*FortEntries*/, NULL /*ExternEntries*/);
}
          
void
R_unload_treeApply(DllInfo *info)
{
  /* Release resources. */
}
