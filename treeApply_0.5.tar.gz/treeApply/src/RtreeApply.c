
#include <R.h>
#include <Rdefines.h>
#include <Rinternals.h>



static SEXP lang_rapply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env);
static SEXP vector_rapply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env);
static SEXP closure_rapply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env);

static SEXP shallow_copy(SEXP object);

static SEXP apply_call(SEXP object, SEXP call, SEXP symbol, SEXP env);

static SEXP delete_node_ptr = 0;
static Rboolean is_delete_ptr(SEXP object);

#define COPY_TAG(to, from) do { \
  SEXP __tag__ = TAG(from); \
  if (__tag__ && __tag__ != R_NilValue) SET_TAG(to, __tag__); \
} while (0)


SEXP R_do_rec_apply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env)
{
    switch(TYPEOF(object)) {
    case LANGSXP: case LISTSXP: 
	return lang_rapply(object, post_call, symbol, pre_call, leaf_call, env);
    case VECSXP: case EXPRSXP:
	return vector_rapply(object, post_call, symbol, pre_call, leaf_call, env);
    case CLOSXP:
	return closure_rapply(object, post_call, symbol, pre_call, leaf_call, env);
    default: /* error ? */
	return object;
    }
}

    
static SEXP lang_rapply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env)
{
    SEXP value, sp, spp;
    int nprotect = 0;
    PROTECT(value = shallow_copy(object)); nprotect++;
    PROTECT(value = apply_call(value, pre_call, symbol, env)); nprotect++;
    sp = value; spp = value;
    while(sp != R_NilValue) {
	SEXP el, elOrig;
	el = elOrig = CAR(sp);
	if(isPairList(el))
	    PROTECT(el = lang_rapply(el, post_call, symbol, pre_call, leaf_call, env));
	else 
	    PROTECT(el = apply_call(el, leaf_call, symbol, env));
	nprotect++;
	if(el != elOrig) {
	    if(is_delete_ptr(el)) { /* delete this element from the value */
		if(sp == spp) { /* first element */
		    value = CDR(sp);
		    sp = CONS(R_NilValue, value);
		}
		else {
		    SETCDR(spp, CDR(sp));
		    sp = spp; 
		}
	    }
	    else {
		COPY_TAG(el, elOrig);
		SETCAR(sp, el);
	    }
	}
	spp = sp;
	sp = CDR(sp);
    }
    value = apply_call(value, post_call, symbol, env);
    UNPROTECT(nprotect);
    return value;
}    

static SEXP vector_rapply(SEXP object, SEXP post_call, SEXP symbol, SEXP pre_call, SEXP leaf_call, SEXP env)
{
    SEXP value, attrib, omit = 0;
    int nprotect = 0, nels, i, j;
    nels = length(object);
    PROTECT(value = allocVector(TYPEOF(object), nels));  nprotect++;
    /* a shallow copy of the vector list */
    for(i=0; i < nels; i++)
	SET_VECTOR_ELT(value, i, VECTOR_ELT(object, i));
    attrib = ATTRIB(object);
    if(attrib && attrib != R_NilValue)
	SET_ATTRIB(value, duplicate(attrib));
    SET_OBJECT(value, OBJECT(object));
    PROTECT(value = apply_call(value, pre_call, symbol, env)); nprotect++;
    PROTECT(omit = allocVector(INTSXP, nels - i)); nprotect++;
    for(i=j=0; i<nels; i++) {
	SEXP el, elOrig;
	el = elOrig = VECTOR_ELT(value, i);
	if(isVectorList(el))
	    PROTECT(el = vector_rapply(el, post_call, symbol, pre_call, leaf_call, env));
	else 
	    PROTECT(el = apply_call(el, leaf_call, symbol, env));
	if(el != elOrig && is_delete_ptr(el))
	  INTEGER(omit)[j++] = -(i+1);
	else
	  SET_VECTOR_ELT(value, i, el);
	UNPROTECT(1);
    }
    if(j > 0) {
	SEXP subset, e;
	PROTECT(subset = allocVector(LANGSXP, 3));
	SETCAR(subset, install("["));
	e = CDR(subset); SETCAR(e, value);
	SETLENGTH(omit, j);
	e = CDR(e); SETCAR(e, omit);
	value = eval(subset, env);
	UNPROTECT(1);
    }
    value = apply_call(value, post_call, symbol, env);
    UNPROTECT(nprotect);
    return value;
}

static SEXP closure_rapply(SEXP object, SEXP post_call, SEXP symbol,
			   SEXP pre_call, SEXP leaf_call, SEXP env)
{
    SEXP formals = FORMALS(object), body = BODY(object);
    int nprotect, ftype, btype;
    ftype = TYPEOF(formals); btype = TYPEOF(body); /* LISTSXP, LANGSXP presumably */
    PROTECT(formals = lang_rapply(formals, post_call, symbol, pre_call, leaf_call, env));
    PROTECT(body = lang_rapply(body, post_call, symbol, pre_call, leaf_call, env));
    nprotect = 2;
    if(ftype == TYPEOF(formals) && btype == TYPEOF(body)) {
	SET_FORMALS(object, formals);
	SET_BODY(object, body);
    }
    else {
	PROTECT(object = allocVector(VECSXP, 2)); nprotect++;
	SET_VECTOR_ELT(object, 0, formals);
	SET_VECTOR_ELT(object, 1, body);
    }
    UNPROTECT(nprotect);
    return(object);
}

/* shallow copy of LANGSXP, LISTSXP, etc. 
   This should exist somewhere ? */

static SEXP shallow_copy(SEXP object)
{
    SEXP value, p, pp;
    int nprotect = 0;
    if(!isPairList(object) || length(object) == 0)
      return object;
    PROTECT(value = allocVector(TYPEOF(object), length(object))); nprotect++;
    p = object; pp = value;
    while(p != R_NilValue && CAR(p) != R_NilValue) {
	SETCAR(pp, CAR(p));
	COPY_TAG(pp, p);
	SET_ATTRIB(pp, ATTRIB(p));
	pp = CDR(pp);
	p = CDR(p);
    }
    SET_TYPEOF(value, TYPEOF(object));
    COPY_TAG(value, object);
    UNPROTECT(nprotect);
    return(value);
}

static SEXP apply_call(SEXP object, SEXP expr, SEXP symbol, SEXP env)
{
    if(TYPEOF(expr) == LANGSXP &&
       /* unfortunately, R uses the contents of an object to detect
	  missing arguments, meaning that assigning R_MissingArg to
	  anything totally confuses any function calls:  */
	object != R_MissingArg) {
	defineVar(symbol, object, env);
	return eval(expr, env);
    }
    else return object;
}

SEXP R_do_tree_delete_node()
{
    if(delete_node_ptr == 0) {
	delete_node_ptr = install("\001DeLeTe_NoDe\001");
	R_PreserveObject(delete_node_ptr);
    }
    return delete_node_ptr;
}

static Rboolean is_delete_ptr(SEXP object)
{
    return delete_node_ptr && object == delete_node_ptr;
}

SEXP OOP_object_copy(SEXP object)
{
    return duplicate(object);
}


