"treeNodeDelete" <-
function()
    .Call("R_do_tree_delete_node", PACKAGE = "treeApply")

