"treeApply" <-
function(object, expr = NULL, env = new.env(parent = parent.frame()),
             leafExpr = expr,
             name = quote(x), preExpr = NULL) {
        makeCall <- function(f, name) {
            ## if f is a function or the name of a function, construct a
            ## call to that function, passing the symbol name as the argument
            ## Otherwise, assume f is some expression to be evaluated, and return f.
            if(is.name(f)) {
                fname <- as.character(f)
                if(identical(f, name) ||
                   !exists(fname) || !is.function(get(fname)))
                    return(f) ## leave as a name; else
                ## treat as a function name
            }
            else if(is.character(f))
                f <- as.name(f)
            else if(!is.function(f))
                return(f)
            as.call(list(f, name))
        }
        if(!is.name(name))
            name <- as.name(name)
        expr <- makeCall(expr, name)
        preExpr <- makeCall(preExpr, name)
        leafExpr <- makeCall(leafExpr, name)
        value <- .Call("R_do_rec_apply", object, expr, name, preExpr, leafExpr, env, PACKAGE="treeApply")
        if(is.function(value))
            ## if "source" included, it masks any changes!!
            attr(value, "source") <- NULL
        value
    }

