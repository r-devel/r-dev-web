#include <stdlib.h>

void ctest1(void)
{
    srand(123);
    int x = rand();
    unsigned int seed = 123;
    unsigned int *seedp = &seed;
    int xx = rand_r(seedp);

    srandom(123);
    long y = random();
    // srandom_r is not portable

    srand48(123L);
    double z = drand48();
}

#undef NDEBUG
#include <assert.h>
#include <unistd.h>

void ctest2(void)
{
    exit(0);
    // _exit is not universal
    _exit(0);
    _Exit(0);

    assert(1==1);

    abort();
}

#include <stdio.h>
#include <stdarg.h>

void ctest3(void)
{
    printf("testit %d\n", 666);
    fprintf(stdout, "testit %d\n", 666);
    fprintf(stderr, "testit %d\n", 666);
    puts("test string");
    putchar(321);

    char out[100];
    sprintf(out, "testit %d", 666);
}

void ctest4(char *fmt, ...)
{
    va_list ap, ap2;
    char out[100];
	
    va_start(ap, fmt);
    va_copy(ap2, ap);
    vprintf(fmt, ap);
    va_end(ap);
    vsprintf(out, fmt, ap);
    va_end(ap2);	
}
