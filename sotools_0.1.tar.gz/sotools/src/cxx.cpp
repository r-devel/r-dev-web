/*
      "linux, C++, gxx, std::cout, _ZSt4cout",
      "linux, C++, gxx, std::cerr, _ZSt4cerr",
*/

#include <iostream>

void cpptest(void)
{
    std::cout << "test1";
    std::cerr << "test1";
}
